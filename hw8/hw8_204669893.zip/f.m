%   FUNCTION DEFINITION FOR HOMEWORK 8 PROBLEM 2

function y = f(x)

    y = 816*x.^3 - 3835*x.^2 + 6000*x - 3125;
    
end